// This is the js for the default/index.html view.
var nodes;
var dataReady = true;
var rotate = true;
var firstLoad = true;
var firstGraph = true;
function startRotation(){
    rotate = true;
}
function stopRotation(){
    rotate = false;
}
    
var app = function() {
    
    

    var self = {};

    Vue.config.silent = false; // show all warnings

    self.get_auth = function(){
        if(!is_logged_in){return;}
        $.getJSON(get_auth_url, function(data){
            self.vue.current_user = data.user;
            
        });
        
    }
    
    self.get_auth();
    
    // Extends an array
    self.extend = function(a, b) {
        for (var i = 0; i < b.length; i++) {
            a.push(b[i]);
        }
    };

    // Enumerates an array.
    var enumerate = function(v) { var k=0; return v.map(function(e) {e._idx = k++;});};
    
    self.add_button = function() {
        $("#add_button").hide();
        $("#add_post").show();
    }
    
    self.add_post = function () {
        dataReady = false;
        // We disable the button, to prevent double submission.
        $.web2py.disableElement($("#add-post"));
        var sent_title = self.vue.form_title; // Makes a copy 
        var sent_tags = self.vue.form_tags;
        var sent_content = self.vue.form_content; // 
        if (self.vue.form_content == "") {
            $("#add_post").hide();
        $("#add_button").show();
            return;}
        $.post(add_post_url,
            // Data we are sending.
            {
                post_title: self.vue.form_title,
                //post_tags: self.vue.form_tags,
                post_content: self.vue.form_content
                
            },
            // What do we do when the post succeeds?
            function (data) {
                // Re-enable the button.
                $.web2py.enableElement($("#add-post"));
                // Clears the form.
                self.vue.form_title = "";
                //self.vue.form_tags = "";
                self.vue.form_content = "";
                // Adds the post to the list of posts. 
                var new_post = {
                    id: data.post_id,
                    post_title: sent_title,
                    post_author: self.vue.current_user,
                    post_content: sent_content
                };
                self.vue.post_list.unshift(new_post);
                // We re-enumerate the array.
                //self.vue.graph.nodeRelVal();

                self.process_posts();
                self.update_graph();
            
            //nodes = self.vue.post_list;
            
            });
        $("#add_post").hide();
        $("#add_button").show();
        // If you put code here, it is run BEFORE the call comes back.
        
    };
    
    self.search_post_list = function() {
        var search_text = document.getElementById("search_text").value;
        ///console.log(search_text);
        if(search_text.trim() == "") {self.get_posts(); return;}
        if(search_text.charAt(0) == '#'){
            //search_text = search_text.slice(1);
        
        $.getJSON(tag_search_url, {tag: search_text},
            function(data) {
                // I am assuming here that the server gives me a nice list
                // of posts, all ready for display.
                self.vue.post_list = data.post_list;
                // Post-processing.
                self.process_posts();
                console.log("I got my list");
                nodes = self.vue.post_list;
                //console.log(counts);
                if(firstGraph){self.make_graph();firstGraph=false;}
                
           
            
            }
        );
        } else if (search_text.charAt(0) == '@'){
            search_text = search_text.slice(1);
            $.getJSON(author_search_url, {post_author: search_text},
            function(data) {
                // I am assuming here that the server gives me a nice list
                // of posts, all ready for display.
                self.vue.post_list = data.post_list;
                // Post-processing.
                self.process_posts();
               // console.log(search_text);
                nodes = self.vue.post_list;
                //console.log(counts);
                if(firstGraph){self.make_graph();firstGraph=false;}
                
           
            
            }
        );
        }
    }
    
    self.get_posts = function() {
        $.getJSON(get_post_list_url,
            function(data) {
                // I am assuming here that the server gives me a nice list
                // of posts, all ready for display.
                self.vue.post_list = data.post_list;
                // Post-processing.
                self.process_posts();
                console.log(self.vue.post_list);
                //nodes = self.vue.post_list;
                //console.log(counts);
                if(firstGraph){self.make_graph();firstGraph=false;}
                
           
            
            }
        );
        
    };

    self.process_posts = function() {
        
        // This function is used to post-process posts, after the list has been modified
        // or after we have gotten new posts. 
        // We add the _idx attribute to the posts. 
        enumerate(self.vue.post_list);
        // We initialize the up status to match the like. 
        self.vue.post_list.map(function (e) {
            // I need to use Vue.set here, because I am adding a new watched attribute
            // to an object.  See https://vuejs.org/v2/guide/list.html#Object-Change-Detection-Caveats
            // Did I like it? 
            // If I do e._up = e.like, then Vue won't see the changes to e._up . 
            Vue.set(e, '_up', e.like); 
            Vue.set(e, '_down', e.dislike); 
            // Who liked it?
            Vue.set(e, '_likers', 0);
            Vue.set(e, '_dislikers', 0);
            Vue.set(e, '_count', 0);
            // Do I know who liked it? (This could also be a timestamp to limit refresh)
            Vue.set(e, '_likers_known', false);
            Vue.set(e, '_dislikers_known', false);
            // Do I show who liked? 
            Vue.set(e, '_show_likers', false);
            Vue.set(e, '_show_dislikers', false);
            Vue.set(e, '_show_count', false);
            Vue.set(e, '_selected', false);
            
            var words = e.post_content.split(" ");
            var tags = []; var mentions = [];
            for(var i = 0; i < words.length; i++){
                if(words[i].charAt(0) == "#"){
                    tags.push(words[i].slice(1));
                } else if (words[i].charAt(0) == "@"){
                    mentions.push(words[i].slice(1));
                }
            }
            Vue.set(e, '_tags', tags);
            Vue.set(e, '_mentions', mentions);
            //get count data
            if (!e._likers_known) {
                $.getJSON(get_likers_url, {post_id: e.id}, function (data) {
                    e._likers = data.likers.length
                    e._likers_known = true;
                    if (!e._dislikers_known) {
                        $.getJSON(get_dislikers_url, {post_id: e.id}, function (data) {
                            e._dislikers = data.dislikers.length
                            e._dislikers_known = true;
                            e._count = e.like ? 1 : e.dislike ? -1 : 0; 
                            e._count += (e._likers - e._dislikers);
                            //c.push(e._count);
                            e._show_count = true;
                            if(e._idx==self.vue.post_list.length-1){self.update_graph();}
                        })
                    }
                })
            }
            
        });
        

    };

    // Up change code. 
    self.like_mouseover = function (post_idx) {
        // When we mouse over something, the face has to assume the opposite
        // of the current state, to indicate the effect.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        if(!p.like){
            p._up = !p.like;
            if(p.dislike){p._down = !p.dislike;}
        }
    };
    
    

    self.like_click = function (post_idx) {
        // The like status is toggled; the UI is not changed.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        if(p.dislike){
            p.dislike = p.like;
            for(var i = 0; i < p.dislikers_list.length; i++){
                if(p.dislikers_list[i] == self.vue.current_user){
                    p.dislikers_list.splice(i,1); 
                    p.likers_list.push(self.vue.current_user);
                }
            }
            $.post(set_dislike_url, {
                post_id: p.id,
                dislike: p.dislike
            });
            //self.dislike_mouseout(post_idx);
        } else if(p.like){
            for(var i = 0; i < p.likers_list.length; i++){
                if(p.likers_list[i] == self.vue.current_user){
                    p.likers_list.splice(i,1); 
                    //p.likers_list.push(self.vue.current_user);
                }
            }
        } else { p.likers_list.push(self.vue.current_user); }
        p.like = !p.like;
        // We need to post back the change to the server.
        $.post(set_like_url, {
            post_id: p.id,
            like: p.like
        }); // Nothing to do upon completion.
        //self.get_posts();
        console.log(p.likers_list);
        self.update_graph();
    };

    self.like_mouseout = function (post_idx) {
        // The like and up status coincide again.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        p._up = p.like;
        if(p._down != p.dislike){ p._down = p.dislike;}
    };
    
    self.show_count = function(post_idx) {
        var p = self.vue.post_list[post_idx];
        //p._show_likers = true;
        if (!p._likers_known) {
            $.getJSON(get_likers_url, {post_id: p.id}, function (data) {
                p._likers = data.likers.length
                p._likers_known = true;
            })
        }
        //p._show_dislikers = true;
        if (!p._dislikers_known) {
            $.getJSON(get_dislikers_url, {post_id: p.id}, function (data) {
                p._dislikers = data.dislikers.length
                p._dislikers_known = true;
            })
        }
        if(p._likers_known && p._dislikers_known){
             p._count = (p.like ? 1 : p.dislike ? -1 : 0) + (p._likers - p._dislikers);
             p._show_count = true;
        }
    };

    // Up change code. 
    self.dislike_mouseover = function (post_idx) {
        // When we mouse over something, the face has to assume the opposite
        // of the current state, to indicate the effect.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        
        if(!p.dislike){
            p._down = !p.dislike;
            if(p.like){p._up = !p.like;}
        }
    };

    self.dislike_click = function (post_idx) {
        // The like status is toggled; the UI is not changed.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        if(p.like){
            p.like = p.dislike;
            for(var i = 0; i < p.likers_list.length; i++){
                if(p.likers_list[i] == self.vue.current_user){
                    p.likers_list.splice(i,1); 
                    p.dislikers_list.push(self.vue.current_user);
                }
            }
            $.post(set_like_url, {
                post_id: p.id,
                dislike: p.like
            });
            //self.dislike_mouseout(post_idx);
        } else if(p.dislike){
            for(var i = 0; i < p.dislikers_list.length; i++){
                if(p.dislikers_list[i] == self.vue.current_user){
                    p.dislikers_list.splice(i,1); 
                    //p.likers_list.push(self.vue.current_user);
                }
            }
        } else { p.dislikers_list.push(self.vue.current_user); }

        p.dislike = !p.dislike;
        // We need to post back the change to the server.
        $.post(set_dislike_url, {
            post_id: p.id,
            dislike: p.dislike
        }); // Nothing to do upon completion.
        self.update_graph();
    };

    self.dislike_mouseout = function (post_idx) {
        // The like and up status coincide again.
        var p = self.vue.post_list[post_idx];
        if(p.post_author == self.vue.current_user)return;
        p._down = p.dislike;
        if(p._up != p.like){ p._up = p.like;}
    };
    
    self.delete_post = function(post_idx){
        dataReady = false;
        var p = self.vue.post_list[post_idx];
        $.post(delete_post_url,
               {post_id: p.id});
        self.vue.post_list.splice(post_idx,1);
        nodes = self.vue.post_list;
        self.process_posts();
        self.update_graph();
        
    }
    
    self.build_links = function(){
        
        for(var i = 0; i < self.vue.post_list.length; i++){
            if(self.vue.post_list[i].post_author == null || self.vue.post_list[i].post_author == null) {continue;}
            
            for(var j = 0; j < self.vue.tags.length; j++){
                if(self.vue.post_list[i]._tags.includes(self.vue.tags[j].label)){
                    self.vue.graph_data.links.push({source:self.vue.post_list[i].id, target:self.vue.tags[j].id, color: "#6666ff"});
                }
            }
            
            for(var j = 0; j < self.vue.users.length; j++){
                if(self.vue.post_list[i].post_author.includes(self.vue.users[j].label)){
                    self.vue.graph_data.links.push({source:self.vue.post_list[i].id, target:self.vue.users[j].id, color:"#ffaa33"});
                }
                if(self.vue.post_list[i]._mentions == null) continue;
                for(var k = 0; k < self.vue.post_list[i]._mentions.length; k++){
               //console.log(self.vue.post_list[i]._mentions[k]);
                   if(self.vue.post_list[i]._mentions[k] == null) continue;
                    if(self.vue.post_list[i]._mentions[k].includes(self.vue.users[j].label)){self.vue.graph_data.links.push({source:self.vue.post_list[i].id, target:self.vue.users[j].id,color:"#ffff33"});} 
            }
                
                //console.log(self.vue.users[j].label);
                //console.log(self.vue.post_list[i]._mentions);
                if(self.vue.post_list[i].likers_list == null) continue;
                for(var k = 0; k < self.vue.post_list[i].likers_list.length; k++){
                    
                 if(self.vue.post_list[i].likers_list[k] == null) continue;
                    if(self.vue.post_list[i].likers_list[k].includes(self.vue.users[j].label)){self.vue.graph_data.links.push({source:self.vue.post_list[i].id, target:self.vue.users[j].id,color:"#33ff33"});} 
            }
                if(self.vue.post_list[i].dislikers_list == null) continue;
                 
                for(var k = 0; k < self.vue.post_list[i].dislikers_list.length; k++){
                   if(self.vue.post_list[i].dislikers_list[k] == null) continue; if(self.vue.post_list[i].dislikers_list[k].includes(self.vue.users[j].label)){self.vue.graph_data.links.push({source:self.vue.post_list[i].id, target:self.vue.users[j].id,color:"#ff3333"});} 
            }
            
                
            }
            
        }
    }
    
    self.build_nodes = function(){
        self.vue.tags = [];
        self.vue.users = [];
        var tags = [];
        var users = [];
        for(var i = 0; i < self.vue.post_list.length; i++){
            
            //console.log(self.vue.post_list[i].post_title);
            //var tags_i = self.vue.post_list[i].post_title.split(" ");
            //console.log(tags_i);
            var tags_i = self.vue.post_list[i]._tags;
            var users_i = self.vue.post_list[i].post_author;
            if(!users.includes(users_i)){
                users.push(users_i);
                self.vue.users.push({id:users_i, label:users_i, color:'#ffaa33'});
            }
            for(var j = 0; j < tags_i.length; j++){
                if(!tags.includes(tags_i[j]) && tags_i[j] != ""){
                    tags.push(tags_i[j]);
                    self.vue.tags.push({id:tags_i[j], label:tags_i[j], color:'#3333ff', size:5});
                }else{
                    for(var k = 0; k < self.vue.tags.length; k++){
                        if(self.vue.tags[k].id == tags_i[j]){
                            //console.log(self.vue.tags[k].size);
                            self.vue.tags[k].size *= 2;
                        }
                    }
                }
            }
        }
        //console.log(self.vue.tags);
    }
    
    self.update_graph = function(){
        self.vue.graph_data = {
            nodes: [],
            links: []
        };
        //console.log(self.vue.graph_data);
        
      
      
        
        self.build_nodes();
        self.build_links();
        self.vue.graph_data.nodes = self.vue.post_list.concat(self.vue.tags.concat(self.vue.users));
        
        self.vue.graph.graphData(self.vue.graph_data);
    }
    
    self.make_graph = function(){
        self.vue.graph_data = {
            nodes: [],
            links: []
        };
        //console.log(self.vue.graph_data);
        
      
        self.build_nodes();
        self.build_links();
        
        self.vue.graph_data.nodes = self.vue.post_list.concat(self.vue.tags.concat(self.vue.users));
      // self.build_nodes();
   // console.log(Graph);
   // .d3Force('link').distance(link => (1/link.weight^(10))*10);
        
        //const distance = 1000;
        self.vue.graph = ForceGraph3D()(document.getElementById('3d-graph'))
        .enableNodeDrag(false)
        .enableNavigationControls(true)
        .showNavInfo(false)
        //.cameraPosition({ z: distance })
        .width(window.innerWidth*0.7)
        .height(window.innerHeight*0.80)
        .nodeVal(node => node._count != null ? Math.abs(node._count)*20 : node.size)
        .nodeColor(node => node._selected ? "#ffffff" : node._count < 0 ? '#ff3333' : node._count > 0 ? '#33ff33' : node._count == 0 ? '#aaaaaa' : node.color)
        //.nodeLabel(node => Math.abs(node._count*1000))
        .nodeLabel(node => node.label)
        .linkLabel(link => link.label)
        .linkWidth(link => 2)
        .onNodeClick(node => {
            if(node.color == '#3333ff'){
                document.getElementById("search_text").value = "#" + node.id;
                self.search_post_list();
            }
            else if(node.color == '#ffaa33'){
                document.getElementById("search_text").value = "@" + node.id;
                self.search_post_list();
            } else {
                var n = document.getElementById(node.id);
                n.scrollIntoView();
                n.style.backgroundColor = "rgb(200,200,255)";

               setTimeout(function() {
                  n.style.backgroundColor = "rgb(200,200,245)";
               }, 300);
                setTimeout(function() {
                  n.style.backgroundColor = "rgb(200,200,235)";
               }, 600);
                setTimeout(function() {
                  n.style.backgroundColor = "rgb(200,200,225)";
               }, 900);
                setTimeout(function() {
                  n.style.backgroundColor = "rgb(200,200,215)";
               }, 1200);
                setTimeout(function() {
                  n.style.backgroundColor = "rgb(200,200,205)";
               }, 1600);
                
                    
                
                
   
                //n.style.backgroundColor = "#ffffff";


          // Aim at node from outside it
          const distance = 300;
          const distRatio = 1 + distance/Math.hypot(node.x, node.y, node.z);
          self.vue.graph.cameraPosition(
            { x: node.x * distRatio, y: node.y * distRatio, z: node.z * distRatio }, // new position
            node, // lookAt ({ x, y, z })
            3000  // ms transition duration
          );}
        })
        
        .cameraPosition({x: 0,y: 0,z: Math.cbrt(self.vue.graph_data.nodes.length) * 200})
        
      //angle += Math.PI / 1000;
        .graphData(self.vue.graph_data);
        self.vue.graph.d3Force('link').distance(link => 100 );
        self.vue.graph.d3Force('collide', d3.forceCollide(self.vue.graph.nodeRelSize()+30));
        
        var colorFlash = 0;
        setInterval(() => {
            colorFlash += 0.2;
            var cf = Math.sin(colorFlash);
            self.vue.graph.nodeColor(node => node._selected ? node._count < 0 ? 'rgb(255,' + 255*cf + ', ' + 255*cf  +')' : node._count > 0 ? 'rgb('+ 255*cf +', 255, ' + 255*cf + ')' : node._count == 0 ? 'rgb('+ 255*cf +', '+ 255*cf +', ' + 255*cf + ')'  : node.color : node._count < 0 ? '#ff3333' : node._count > 0 ? '#33ff33' : node._count == 0 ? '#aaaaaa'  : node.color)
        }, 10);

    }
    
    
    
    self.selectPost = function(post_idx){
        var p = self.vue.post_list[post_idx];
        p._selected = true;
        self.vue.graph_data.nodes = self.vue.post_list.concat(self.vue.tags.concat(self.vue.users));
        //console.log(self.vue.post_list[post_idx])
    }
    
    self.deselectPost = function(post_idx){
        var p = self.vue.post_list[post_idx];
        p._selected = false;
        self.vue.graph_data.nodes = self.vue.post_list.concat(self.vue.tags.concat(self.vue.users));
        //self.update_graph();
        //console.log(self.vue.post_list[post_idx])
    }
    
    self.focusNode = function(post_idx){
        var p = self.vue.post_list[post_idx];
        var data = self.vue.graph.graphData();
        var node = data.nodes[data.nodes.indexOf(p)];
        const distance = 300;
          const distRatio = 1 + distance/Math.hypot(node.x, node.y, node.z);
          self.vue.graph.cameraPosition(
            { x: node.x * distRatio, y: node.y * distRatio, z: node.z * distRatio }, // new position
            node, // lookAt ({ x, y, z })
            3000  // ms transition duration
          );
    }
    

    // Complete as needed.
    self.vue = new Vue({
        el: "#vue-div",
        delimiters: ['${', '}'],
        unsafeDelimiters: ['!{', '}'],
        data: {
            form_title: "",
            form_tags: "",
            form_content: "",
            post_list: [],
            tags: [],
            users: [],
            graph_data: null,
            graph: null,
            current_user: null,
            is_logged_in: is_logged_in
        },
        methods: {
            add_button: self.add_button,
            add_post: self.add_post,
            // Likers. 
            like_mouseover: self.like_mouseover,
            like_mouseout: self.like_mouseout,
            like_click: self.like_click,
            // Show/hide who liked.
            show_likers: self.show_likers,
            hide_likers: self.hide_likers,
            show_count: self.show_count,
            search_post_list: self.search_post_list,
            // Dislikers. 
            dislike_mouseover: self.dislike_mouseover,
            dislike_mouseout: self.dislike_mouseout,
            dislike_click: self.dislike_click,
            // Show/hide who disliked.
            show_dislikers: self.show_dislikers,
            hide_dislikers: self.hide_dislikers,
            delete_post: self.delete_post,
            make_graph: self.make_graph,
            update_graph: self.update_graph,
            build_links: self.build_links,
            build_nodes: self.build_nodes,
            get_auth: self.get_auth,
            selectPost: self.selectPost,
            deselectPost: self.deselectPost,
            focusNode: self.focusNode
        }
    });

    // If we are logged in, shows the form to add posts.
    if (is_logged_in) {
        $("#add_button").show();
        
    }

    // Gets the posts.
    self.get_posts();
    

    return self;
};

var APP = null;

// No, this would evaluate it too soon.
// var APP = app();

// This will make everything accessible from the js console;
// for instance, self.x above would be accessible as APP.x
jQuery(function(){APP = app();});


function updateGraph(nodes){
    const Graph = ForceGraph3D()
      (document.getElementById('3d-graph')).nodeLabel(node => 'updated');
}
